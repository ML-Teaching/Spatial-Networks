#############################################################
# ui.R
# -----------------------------------------------------------
# Ce fichier définit l'interface utilisateur de l'application
# Shiny : structure, onglets, carte et panneaux de contrôle
#############################################################

shinyUI(
  
  # Barre de navigation
  navbarPage(
    
    # Titre affiché en haut de l'application
    # HTML() permet d'utiliser du code HTML pour la mise en forme
    title = HTML(
      '<span style="font-size:120%;
                    color:white;
                    font-weight:bold;">
       Nom app &nbsp;&nbsp;
       </span>'
    ),
    
    # Titre de la fenêtre du navigateur
    windowTitle = "Nom fenetre",
    
    # Onglet principal    
    tabPanel(
      
      # Nom de l'onglet (en gras)
      strong("Nom onglet"),
      
      # Conteneur principal 
      div(
        class = "outer",
        
        # Feuille de style CSS  
        # Inclusion d'un fichier CSS personnalisé
        # Il permet de modifier l'apparence de l'application
        tags$head(
          includeCSS("styles.css")
        ),
        
        # Carte Leaflet           
        # Emplacement où la carte sera affichée
        # L'objet "map" est défini dans server.R
        leafletOutput(
          "map",
          width = "100%",
          height = "100%"
        ),
        
        # Panneau de contrôle   
        absolutePanel(
          id = "control",
          class = "panel panel-default",
          
          # Le panneau reste fixe à l'écran
          fixed = TRUE,
          
          # Le panneau peut être déplacé à la souris
          draggable = TRUE,
          
          # Position du panneau sur l'écran
          top = 80,
          left = "auto",
          right = 20,
          bottom = "auto",
          
          # Dimensions du panneau
          width = 350,
          height = "auto",
          
          # Titre du panneau        
          h2("Explorateur"),
          
          # Menu déroulant          
          # selectInput crée une liste déroulante
          # Elle permet à l'utilisateur de choisir le type de flux
          selectInput(
            inputId = "type",
            
            # Texte affiché au-dessus du menu
            label = strong("Type de flux"),
            
            # Valeurs proposées à l'utilisateur
            # Le texte à gauche est affiché,
            # la valeur à droite est utilisée dans server.R
            choices = list(
              "Flux sortants" = "Out_Commuters",
              "Flux entrants" = "In_Commuters",
              "Ratio" = "Ratio"
            ),
            
            # Valeur sélectionnée par défaut
            selected = "Out_Commuters"
          )
          
        )
      )
    )
  )
)
