##############################################################
# global.R
# ------------------------------------------------------------
# Ce script contient les éléments globaux de l'application
# Shiny : chargement des librairies et préparation des données
##############################################################

# Chargement des packages 
library(TDLM)
library(shiny)          # Package shiny pour faire tourner les applications
library(leaflet)        # Cartes
library(sf)
library(RColorBrewer)   # Couleurs

# Chargement des données
data(mass_mtp)
data(mtp)

# Ajout des masses à la table attributaire 
mtp <- cbind(mtp, mass_mtp)

# Création d'un ratio et ajout à la table attributaire
mtp$Ratio <- mtp$Out_Commuters / mtp$In_Commuters
