############################################################
# server.R
# ----------------------------------------------------------
# Ce fichier définit la logique serveur de l'application
# Shiny : calculs réactifs et affichage de la carte
############################################################

shinyServer(function(input, output) {
  
  # reactive() permet de recalculer automatiquement le contenu
  # dès qu'une entrée utilisateur (input) change
  reacmap <- reactive({

    # Récupération du type de flux choisi par l'utilisateur
    # (ex : In_Commuters, Out_Commuters ou Ratio)
    type <- input$type
    
    # Suppression de la géométrie pour ne garder que les données
    # attributaires, puis sélection de la variable choisie
    flux <- st_drop_geometry(mtp)[[type]]
    
    # Création d'une palette de couleurs graduées
    # à partir de la palette YlOrRd (jaune -> rouge)
    cololeg <- colorRampPalette(brewer.pal(9, "YlOrRd"))(13)
    
    # Définition des seuils de classes
    # -1 permet d'inclure les valeurs nulles ou très faibles
    classes <- c(-1,
                 seq(100, 1000, 100),
                 5000,
                 10000,
                 100000)
    
    # Légendes associées à chaque classe
    legendes <- c(
      "[0,100]",
      "]100,200]",
      "]200,300]",
      "]300,400]",
      "]400,500]",
      "]500,600]",
      "]600,700]",
      "]700,800]",
      "]800,900]",
      "]900,1000]",
      "]1000,5000]",
      "]5000,10000]",
      "> 10000"
    )
    
    # cut() permet de classer les valeurs dans des intervalles
    # Chaque classe reçoit un numéro (1 à 13)
    cat <- as.numeric(as.character(cut(flux,
                                       breaks = classes,
                                       labels = 1:length(cololeg))))
    
    # Attribution d'une couleur à chaque entité spatiale
    colo <- cololeg[cat]
    
    # On retourne une liste contenant :
    # - les couleurs des entités
    # - la palette de couleurs
    # - les libellés de la légende
    res <- list(colo = colo,
                       cololeg = cololeg,
                       legendes = legendes)
    
  })
  
  
  # Création de la carte interactive
  output$map <- renderLeaflet({
    
    # Initialisation de la carte Leaflet
    leaflet() %>%
      clearShapes() %>%
      clearMarkers() %>%
      clearControls() %>%
      
      # Fond de carte CartoDB clair
      addProviderTiles(providers$CartoDB.Positron) %>%
      
      # Ajout des polygones avec les couleurs calculées
      addPolygons(
        data = mtp,
        color = reacmap()$colo,
        weight = 2,
        smoothFactor = 0.5,
        opacity = 0,
        fillOpacity = 0.5
      ) %>%
      
      # Ajout de la légende
      addLegend(
        position = "bottomleft",
        colors = reacmap()$cololeg,
        labels = reacmap()$legendes,
        opacity = 0.6,
        title = "Taille des flux"
      )
    
  })
  
})
