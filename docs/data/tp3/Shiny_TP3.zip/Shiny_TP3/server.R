############################################################
# server.R
# ----------------------------------------------------------
# Ce fichier définit la logique serveur de l'application
# Shiny : calculs réactifs et affichage de la carte
############################################################


shinyServer(function(input, output) {
  
  
  # reactive() permet de recalculer automatiquement le contenu
  # dès qu'une entrée utilisateur (input) change
  reacmap <- reactive({
    
    # Bioregionalisation           
    clu <- netclu_louvain(sim,
                          index = input$similarity,
                          cut_weight = as.numeric(input$cutw), 
                          seed = 1)
    
    # Cartographie des clusters
    clusf <- map_bioregions(clu, vegesf,
                            write_clusters = TRUE,
                            plot = FALSE)
    
    # Extraire la variable des bioregions comme facteur
    bioregions <- as.factor(clusf[, 2, drop = TRUE])
    
    # Créer une palette de couleurs pour les bioregions
    pal <- colorFactor(
      palette  = "Set2",     # palette prédéfinie
      domain   = bioregions, # correspondance bioregion → couleur
      na.color = "white"     # couleur par défaut si NA
    )
    
    # Associer une couleur à chaque site
    palbio <- pal(bioregions)
    
   # On retourne un objet list contenant toutes les informations
    res <- list(
      clusf      = clusf,      # objet spatial des sites avec clusters
      bioregions = bioregions, # facteur des bioregions
      pal        = pal,        # fonction palette
      palbio     = palbio      # couleurs associées aux sites
    )
    
  })
  
  # Création de la carte  
  output$map <- renderLeaflet({
    
    # Initialisation de la carte Leaflet
    leaflet() %>%
      clearShapes() %>%   # retirer polygones précédents
      clearMarkers() %>%  # retirer markers précédents
      clearControls() %>% # retirer légendes précédentes
      addProviderTiles(providers$CartoDB.Positron) %>%  # fond de carte clair
      
      # Ajout des polygones colorés selon la bioregion
      addPolygons(
        data       = reacmap()$clusf,
        color      = reacmap()$palbio,
        weight     = 2,
        smoothFactor = 0.5,
        opacity    = 0,
        fillOpacity = 0.5
      ) %>%
      
      # Ajout de la légende
      addLegend(
        position = "bottomleft",
        pal      = reacmap()$pal,          # palette de couleurs
        values   = reacmap()$bioregions,   # valeurs à légender
        title    = "Biorégions",           # titre
        opacity  = 1
      )
    
  })
  
  
})
