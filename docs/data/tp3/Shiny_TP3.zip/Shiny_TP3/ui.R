############################################################
# ui.R
# ----------------------------------------------------------
# Ce fichier définit l'interface utilisateur de l'application
# Shiny : structure, onglets, carte et panneaux de contrôle
############################################################

shinyUI(
  
  # Barre de navigation 
  navbarPage(
    # Titre affiché en haut de l'application
    # HTML() permet d'utiliser du code HTML pour personnaliser le style
    title = HTML('<span style="font-size:120%;color:white;font-weight:bold;">
                  Nom app &nbsp;&nbsp;</span>'),
    
    # Titre de la fenêtre du navigateur
    windowTitle = "Nom fenetre",
    
    # Onglet principal
    tabPanel(
      # Nom de l'onglet (en gras)
      strong("Nom onglet"),
      
      # Conteneur principal
      div(
        class = "outer",
        
        # Inclusion du CSS
        tags$head(
          # On inclut un fichier CSS externe pour personnaliser l'apparence
          includeCSS("styles.css")
        ),
        
        # Carte Leaflet 
        leafletOutput(
          "map",       # correspond à output$map dans server.R
          width  = "100%",
          height = "100%"
        ),
        
        # Panneau de contrôle
        absolutePanel(
          id = "control",
          class = "panel panel-default",
          
          # Le panneau reste fixe à l'écran
          fixed = TRUE,
          
          # Le panneau peut être déplacé à la souris
          draggable = TRUE,
          
          # Position du panneau
          top    = 80,
          left   = "auto",
          right  = 20,
          bottom = "auto",
          
          # Dimensions du panneau
          width  = 350,
          height = "auto",
          
          # Titre du panneau
          h2("Explorateur"),
          
          # Menu déroulant
          selectInput(
            inputId = "similarity",  # identifiant utilisé côté serveur
            label   = strong("Métrique de similarité"), # texte au-dessus
            choices = list("Simpson" = 4,  # choix possibles
                           "Jaccard" = 3),
            selected = "Simpson"     # valeur par défaut
          ),
          
          # Curseur pour la coupe 
          # chooseSliderSkin() modifie l'apparence du slider
          chooseSliderSkin("Flat", "#4682B4"),
          sliderInput(
            inputId = "cutw",             # identifiant côté serveur
            label   = strong("Valeur de coupe"), # texte du slider
            value   = 0,                   # valeur par défaut
            min     = 0,                   # valeur minimale
            max     = 1,                   # valeur maximale
            step    = 0.1                  # pas du curseur
          )
          
        ) # fin absolutePanel
        
      ) # fin div.outer
    ) # fin tabPanel
  ) # fin navbarPage
)
