############################################################
# global.R
# ----------------------------------------------------------
# Ce fichier contient les éléments globaux de l'application
# Shiny : chargement des packages et préparation des données
############################################################

# Chargement des packages
library(bioregion)
library(shiny)
library(shinyWidgets)
library(leaflet)
library(sf)
library(RColorBrewer)

# Chargement des données
data(vegemat)
data(vegesf)

# Conversion de la projection
vegesf <- st_transform(vegesf, crs = 4326)

# Calcul de la similarité
sim <- similarity(vegemat, metric = c("Simpson", "Jaccard"))
